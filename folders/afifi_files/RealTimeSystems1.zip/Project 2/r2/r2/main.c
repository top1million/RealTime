#include <stdio.h>
#include <stdlib.h>


int num_of_passengers;
int crossing_points_pal;
int crossing_points_jor;
int crossing_points_frn;
int num_of_officers;
int num_of_busses;
int bus_capacity;
int bus_sleep_range_s;
int bus_sleep_range_e;
int max_returned;
int max_granted_access;
int max_denied_access;

int f = 0;

int main()
{
    printf("Hello world!\n");
    read_file();
    y(crossing_points_pal,crossing_points_jor,crossing_points_frn,num_of_officers,bus_sleep_range_s,bus_sleep_range_e);

    if (f)
    {
        printf("Data : OK \n ");
    }
    else
    {
        num_of_passengers = 50;
        crossing_points_pal = 5;
        crossing_points_jor = 3;
        crossing_points_frn = 1;
        num_of_officers = 11;
        num_of_busses = 4;
        bus_capacity = 25;
        bus_sleep_range_s = 5 ;
        bus_sleep_range_e = 10;
        max_returned = 60 ;
        max_granted_access = 100 ;
        max_denied_access = 60;

        printf("Data : NO \n SO the Data is : \n");

    }

    printf("num_of_passengers : %d \n",num_of_passengers);
    printf("crossing_points_pal : %d \n",crossing_points_pal);
    printf("crossing_points_jor : %d \n",crossing_points_jor);
    printf("crossing_points_frn : %d \n",crossing_points_frn);
    printf("num_of_officers : %d \n",num_of_officers);
    printf("num_of_busses : %d \n",num_of_busses);
    printf("bus_capacity : %d \n",bus_capacity);
    printf("bus_sleep_range_s : %d \n",bus_sleep_range_s);
    printf("bus_sleep_range_e : %d \n",bus_sleep_range_e);
    printf("max_returned : %d \n",max_returned);
    printf("max_granted_access : %d \n",max_granted_access);
    printf("max_denied_access : %d \n",max_denied_access);

    return 0;
}

void read_file(char* filename)
{

    char fileName[100];
    char repeat[5];
labe2:
    printf("\nEnter the file \" the file name please it must end with {.txt}\" :\n");

    fflush(stdin);
    gets(fileName);

    FILE *in = fopen(fileName, "r");

    while (in == NULL)
    {
        printf("Invalid patients File Name Or File Is Empty\n");
        printf("Do You Want Try again ?( yes if you want )\n");
        scanf("%s",repeat);
        if (strcmp(repeat,"yes")==0)
            goto labe2;
        printf("thank you \n");
        system("pause");
        system("CLS");
        return 0;
    }
    char line[200];
    while (fgets(line,200,in) != NULL)
    {
        char delim [6]=" \n";
        int i =0 ;
        char *token ;

        //  printf(" : %s  \n",line);

        token=strtok(line,delim);
        //      printf(" : %s  \n",token);

        char *token1 ;
        char *token2 ;
        char *token3 ;


        while (token!=NULL)
        {
            if (i==0)
            {
                token1=token;
                //    printf(" %s  \n",token1);
                ++i;
            }
            else if (i==1)
            {
                token2=token;
                //    printf(" %s  \n",token2);
                ++i;
            }
            else if (i==2)
            {
                token3=token;
                //    printf(" %s  \n",token3);
                ++i;
            }
            x(token1,token2,token3);
            token=strtok(NULL,delim);
        }
    }
    fclose(in);
    printf("\nThe reading process was successful from the file (%s) \n\n",fileName);

}

void x(char* a,char* b,char* c)
{
    char str[100]  ;
    strcpy(str,a);
    //    printf(" %s  \n",str);

    char num_of_passengerss[100];
    char crossing_points_pall[100];
    char crossing_points_jorr[100];
    char crossing_points_frnn[100];
    char num_of_officerss[100];
    char num_of_bussess[100];
    char bus_capacityy[100];
    char bus_sleep_range_ss[100];
    char bus_sleep_range_ee[100];
    char max_returnedd[100];
    char max_granted_accesss[100];
    char max_denied_accesss[100];

    char str1[] = "num_of_passengers";
    char str2[] = "crossing_points_pal";
    char str3[] = "crossing_points_jor";
    char str4[] = "crossing_points_frn";
    char str5[] = "num_of_officers";
    char str6[] = "num_of_busses";
    char str7[] = "bus_capacity";
    char str8[] = "bus_sleep_range";
    char str9[] = "max_returned";
    char str10[] = "max_granted_access";
    char str11[] = "max_denied_access";


    int result1 = strcmp(str1, str);
    // printf(" %d  \n",result1);

    if(result1 == 0)
    {
        //    printf(" sad injas 1 : num_of_passengers \n");
        strcpy(num_of_passengerss,b);
        num_of_passengers = atoi(num_of_passengerss);

    }

    int result2 = strcmp(str2, str);
    //        printf(" %d  \n",result2);

    if(result2 == 0)
    {
        //    printf(" sad injas 2\n");
        strcpy(crossing_points_pall,b);
        crossing_points_pal = atoi(crossing_points_pall);
    }

    int result3 = strcmp(str3, str);
    //         printf(" %d  \n",result3);

    if(result3 == 0)
    {
        //    printf(" sad injas3 \n");
        strcpy(crossing_points_jorr,b);
        crossing_points_jor = atoi(crossing_points_jorr);
    }

    int result4 = strcmp(str4, str);
    //        printf(" %d  \n",result4);

    if(result4 == 0)
    {
        //    printf(" sad injas4 \n");
        strcpy(crossing_points_frnn,b);
        crossing_points_frn = atoi(crossing_points_frnn);
    }

    int result5 = strcmp(str5, str);
    //        printf(" %d  \n",result5);

    if(result5 == 0)
    {
        //    printf(" sad injas 5\n");
        strcpy(num_of_officerss,b);
        num_of_officers = atoi(num_of_officerss);
    }

    int result6 = strcmp(str6, str);
    //       printf(" %d  \n",result6);

    if(result6 == 0)
    {
        //    printf(" sad injas6 \n");
        strcpy(num_of_bussess,b);
        num_of_busses = atoi(num_of_bussess);
    }

    int result7 = strcmp(str7, str);
    //      printf(" %d  \n",result7);

    if(result7 == 0)
    {
        //    printf(" sad injas7 \n");
        strcpy(bus_capacityy,b);
        bus_capacity = atoi(bus_capacityy);
    }

    int result8 = strcmp(str8, str);
    //       printf(" %d  \n",result8);

    if(result8 == 0)
    {
        //     printf(" sad injas 8\n");
        strcpy(bus_sleep_range_ss,b);
        strcpy(bus_sleep_range_ee,c);

        bus_sleep_range_s = atoi(bus_sleep_range_ss);
        bus_sleep_range_e = atoi(bus_sleep_range_ee);
    }

    int result9 = strcmp(str9, str);
    //    printf(" %d  \n",result9);

    if(result9 == 0)
    {
        //    printf(" sad injas9 \n");
        strcpy(max_returnedd,b);
        max_returned = atoi(max_returnedd);
    }

    int result10 = strcmp(str10, str);
    //     printf(" %d  \n",result10);

    if(result10 == 0)
    {
        //     printf(" sad injas10 \n");
        strcpy(max_granted_accesss,b);
        max_granted_access = atoi(max_granted_accesss);
    }

    int result11 = strcmp(str11, str);
    //   printf(" %d  \n",result11);

    if(result11 == 0)
    {
        //     printf(" sad injas 11\n");
        strcpy(max_denied_accesss,b);
        max_denied_access = atoi(max_denied_accesss);
    }
}

void y(int a, int b, int c,int q,int z,int s,int e )
{
    a = crossing_points_pal;
    b = crossing_points_jor;
    c = crossing_points_frn;
    z = num_of_officers ;
    s = bus_sleep_range_s ;
    e = bus_sleep_range_e ;

    q = a +b +c ; //q is total_number_of_crossing_points

    if (a > b)
        if(b > c)
            if(z >=q)
                if (s < e)
                {
                    f = 1;
                    printf("OK.. (%d)\n",f);

                }
}
