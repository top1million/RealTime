This Project is For The Group of Students : 
Mohammad Injass 1172260
Mohammad Abuzaineh 1181965
Abdallah Afifi 1182972

You can enter then number of competing children as the first argument. How it will work will depend on your machine. 
It would have been easy and the life would have been simple but generating Random numbers for each child is difficult.
That is why the function "clock()" is used, but when it reaches a big number and takes a long time to calculate "srand()", the children won't work correctly,
and the files won't be created correctly. It worked once with 6 children and another time it worked with 9 children but this was rarely the case. It works most of
the time with 4 or less children adn if you tried to enter less than 2 children it will cause an error.

Enjoy the Race :)