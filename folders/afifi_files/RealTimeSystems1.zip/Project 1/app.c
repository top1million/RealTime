#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <fcntl.h>  //for opening and creating files
#include <limits.h> //for knowing limits of files and other data variables
int exitt = 0;
int start_randomization = 0; //for starting randomization in competing children
int wait_write = 0;          //for waiting between 2 writes to referee
int get_score = 0;
void handle_sigusr1(int sig)
{
    
    start_randomization = 1;
}
void handle_sigint(int sig)
{
    wait_write = 1;
}
void handle_sigquit(int sig)
{
    // printf("Ended random number generation and wrote to file %d\n ", getpid());
    get_score = 1;
}
//--------------------------------------------------------------------------------------------
//-----------------------------------main-----------------------------------------------------
//--------------------------------------------------------------------------------------------
int main(int argc, char *argv[])
{
    int n,j,i,p,l,len = 0;

    if (argc != 2)
    {
        n = 2;
    }
    else
    {
        n = atoi(argv[1]);
        if (n < 2)
        {
            printf("You can't only have %d competing child. We are setting it back to 2\n", n);
            n = 2;
        }
    }
    //n is the number of children

    int fd[2][2]; //number of file descriptors
    // for (i = 0;i<=n;i++){
    if (pipe(fd[0]) < 0)
    {
        return 2;
    }
    if (pipe(fd[1]) < 0)
    {
        return 3;
    }
    // }

    //--------------------------------------------------------------------------------------------
    //-------------------------------------CHILDREN-----------------------------------------------
    //--------------------------------------------------------------------------------------------
    int pid[n + 1];
    for (i = 1; i < n + 1; i++)
    {
        pid[i] = fork();
        if (pid[i] < 0)
        {
            return i + 2;
        }
        //ith child process
        if (pid[i] == 0)
        {

            //closing the pipes
            close(fd[0][0]);
            close(fd[1][0]);
            close(fd[1][1]);
            struct sigaction sa;
            sa.sa_handler = &handle_sigusr1;
            sa.sa_flags = SA_NOCLDWAIT;
            sigaction(SIGUSR1, &sa, NULL);
            //random value to be generated
            // int my_pid = getpid();
            while (1)
            {
                while (!start_randomization);
                start_randomization = 0;
                int v[10];
                for (int k = 0; k < 10; k++)
                {
                    //to give random seeds for each process
                    srand(clock());
                    v[k] = rand() % 100 + 1;
                }


                FILE *ptr;
                char name[FILENAME_MAX];

                snprintf(name, sizeof(name), "child%d.txt", i);
                remove(name); // to make sure it didn't exist before
                ptr = fopen(name, "w");
                if (ptr == NULL)
                {
                    perror("Failed To Create File");
                }

                for (int k = 0; k < 10; k++)
                {

                    if (k != 9)
                    {
                        fprintf(ptr, "%d\n", v[k]);
                    }
                    else
                    {
                        fprintf(ptr, "%d", v[k]);
                    }
                }
                fclose(ptr);
                if (write(fd[0][1], &i, sizeof(int)) < 0)
                {
                    return 11;
                }
            }
            close(fd[0][1]);
            return 0;
        }
    }

    //--------------------------------------------------------------------------------------------
    //--------------------------Setting Up The Parent---------------------------------------------
    //--------------------------------------------------------------------------------------------
    close(fd[0][1]);
    sleep(1);
    int proc_num = 0;
    int counter = 0;
    //making the parent sensitive to the signal
    struct sigaction sa;
    sa.sa_handler = &handle_sigint;
    sa.sa_flags = SA_NOCLDWAIT;
    sigaction(SIGINT, &sa, NULL);
    //- = - = - = - = - = - = - = - = - =
    struct sigaction sa1;
    sa.sa_handler = &handle_sigquit;
    sa.sa_flags = SA_NOCLDWAIT;
    sigaction(SIGQUIT, &sa1, NULL);
    //------------------------------------------------------------
    //----------------Creating the Message------------------------
    //------------------------------------------------------------
    int size = 0;
    if (n < 10)
    {
        size = n * 9 + n - 1 + n + 1; //child.txt = 9 characters + child number + number of dash lines + 1 for null terminator
    }
    else
    {
        size = n * 9 + n - 1 + n + (n - 9) * 2 + 1;
    }

    char msg[size]; // =  (char*)malloc(size*sizeof(char));

    char *num = (char *)malloc(sizeof(char) * 2);
    len = 0;
    for (i = 0; i < n; i++)
    {
        len = 0;
        if (i < 8)
        {
            snprintf(num, sizeof(num), "%d", (int)(i + 1));
            len = 10;
        }
        else
        {
            snprintf(num, sizeof(num), "%d", (int)(i + 1));
            len = 11;
        }
        char *src = (char *)malloc(sizeof(char) * len);
        strcat(src, "child");
        strcat(src, num);
        strcat(src, ".txt");
        strcat(msg, src);

        if (i != n - 1)
        {
            strcat(msg, "-");
        }
    }
    strcat(msg, "\0");

    //--------------------------------------------------------------------------------------------
    //----------------------------------REFEREE---------------------------------------------------
    //--------------------------------------------------------------------------------------------
    int ref_pid = fork();

    if (ref_pid == 0)
    {
        sleep(3);
        close(fd[0][0]);
        close(fd[0][1]);

        int msg_size = 0;
        if (read(fd[1][0], &msg_size, sizeof(int32_t)) < 0)
        {
            perror("Can't read From Pipe\n");
            return 13;
        }

        kill(getppid(), SIGINT); //to tell the parent to send next line of data
        char msg_ref[msg_size];  // = (char*) malloc(sizeof(char) * msg_size);
        if (read(fd[1][0], &msg_ref, sizeof(char) * msg_size) < 0)
        {
            return 13;
        }

        //--------------------------------------------------------------------------------------------
        //--------------------------Decoding The Files Message----------------------------------------
        //--------------------------------------------------------------------------------------------
        char *filenames[n];

        char *token = strtok(msg_ref, "-");
        while ( token[0] != 'c')
        {
            for (int k = 0; k < strlen(token); k++)
            { //because in first tokenisation, it prints " " at the beginning of filename
                token[k] = token[k + 1];
            }
        }
        l = 0;
        // Keep printing tokens while one of the
        // delimiters present in str[].
        while (token != NULL)
        {
            filenames[l++] = token;
            token = strtok(NULL, "-");
        }

        FILE *ptr[n];
        int row_winner = -1;
        int max_row_score = 0;
        char *line; //so we can read lines into it
        int scores[n];
        size_t len;      //to be used later in getline() function.
        int cur_val = 0; //to read into it
        //-------------------------------------------------------------
        //---------------------Start of Ref While Loop-----------------
        //-------------------------------------------------------------
        while (1)
        {
            
            for (i = 0; i < n; i++)
            {
                scores[i] = 0;
            }

            kill(getpid(), SIGSTOP);
            sleep(1);
            for (i = 0; i < n; i++)
            {
                ptr[i] = fopen(filenames[i], "r");
                if (ptr[i] == NULL)
                    printf("%s\t%s\n", strerror(errno), filenames[i]);
            }
            //--------------------------------------------------------------------
            //-------------------Comparing The Values In Files--------------------
            //--------------------------------------------------------------------
            for (i = 0; i < 10; i++)
            {
                
                row_winner = -1;
                max_row_score = 0;
                for (l = 0; l < n; l++)
                {

                    getline(&line, &len, ptr[l]);
                    line[strcspn(line, "\n")] = 0; //to remove \n from read lines
                    
                    cur_val = strtol(line, NULL, 10); //the line, pointer to first incompatible character, the base
                    
                    if (max_row_score < cur_val)
                    {
                        max_row_score = cur_val;
                        
                        row_winner = l;
                    }
                    else if (max_row_score == cur_val)
                    { //if we had 2 similar numbers then no child will have its' score increased
                        max_row_score = 0;
                        row_winner = -1;
                        break;
                    }
                }
                if (row_winner != -1)
                {
                    scores[row_winner]++;
                }

                // for (int l = 0; l < n; l++)
                // {
                //     printf("This is the score of process %d : %d\n", l + 1, scores[l]);
                // }
            }

            //------------------------------------------------------------
            //-------------Writing the Score Back-------------------------
            //------------------------------------------------------------

            int rsize = 0;
            int rdummy = 0;
            rsize = 2 * n + n - 1; //2 is the maximum size of ints, and n - 1 for the -

            char rmsg[rsize]; // =  (char*)malloc(size*sizeof(char));

            char *rnum = (char *)malloc(sizeof(char) * 2);
            int rlen = 0; //length of the character
            for (j = 0; j < n; j++)
            {
                if (scores[j] < 10)
                {
                    snprintf(rnum, sizeof(rnum), "%d", (int)(scores[j]));
                    rlen = 1;
                }
                else
                {
                    snprintf(rnum, sizeof(rnum), "%d", (int)(scores[j]));
                    rlen = 2;
                }
                char *rsrc = (char *)malloc(sizeof(char) * rlen); //first part of the message
                strcat(rsrc, rnum);
                strcat(rmsg, rsrc);

                if (j != n - 1)
                {
                    strcat(rmsg, "-");
                }
            }
            strcat(rmsg, "\0");
            rdummy = strlen(rmsg);

            if (write(fd[1][1], &rdummy, sizeof(int32_t)) < 0)
            {
                perror("Writing from referee to parent the size of the score!\n");
                return 14;
            }
            kill(getpid(), SIGSTOP);
            
            if (write(fd[1][1], &rmsg, sizeof(char) * strlen(rmsg)) < 0)
            {
                perror("Writing from referee to parent the score!\n");
                return 15;
            }
            
            for (l = 0; l < n; l++)
            {
                remove(filenames[l]);
            }
        }

        close(fd[1][0]);
        close(fd[1][1]);
        return 0;
    }

    //--------------------------------------------------------------------------------------------
    //--------------------------BACK TO PARENT----------------------------------------------------
    //--------------------------------------------------------------------------------------------

    // int l = 1;
    // int values[n+1];
    // int max_pos;
    // int max = -1;
    // int scores[n+1];
    //Parent Sending to Referee

    size = strlen(msg) + 1;
    if (write(fd[1][1], &size, sizeof(size)) < 0)
    {
        return 11;
    }
    while (!wait_write); //so we can wite between 2 writes
    wait_write = 0;
    if (write(fd[1][1], &msg, sizeof(char) * size) < 0)
    {
        return 11;
    }
    int BigSums[n];
    for (int s = 0; s < n; s++)
    {
        BigSums[s] = 0;
    }
    int num_of_rounds = 0;
    sleep(1);           //to give time for the processes to create
    int ended_flag = 0; //to know when to quit the game;
    p = 0; //used later in a loop
    while (1)
    {
        num_of_rounds++;
        for (i = 1; i < n + 1; i++)
        {
            kill(pid[i], SIGUSR1);
        }
        //wait for all processes to return success
        do
        {
            if (read(fd[0][0], &proc_num, sizeof(int)) < 0)
            {
                return 13;
            }

            counter++;
        } while (counter != n);
        counter = 0;
        kill(ref_pid, SIGCONT);
        int size_of_score = 0;

        if (read(fd[1][0], &size_of_score, sizeof(int32_t)) < 0)
        {
            perror("Reading Size of Score From Referee in parent!\n");
            return 11;
        }

        char score_text[size_of_score + 1];
        kill(ref_pid, SIGCONT);
        
        if (read(fd[1][0], &score_text, sizeof(char) * (size_of_score)) < 0)
        {
            perror("Reading the Score from referee in Parent!\n");
            return 11;
        }
        
        fflush(stdin);
        
        //--------------------------------------------------------------------------------------------
        //--------------------------Decoding The Score Message----------------------------------------
        //--------------------------------------------------------------------------------------------

        char *token = strtok(score_text, "-");

        l = 0;
        // Keep printing tokens while one of the
        // delimiters present in str[].
        while (token != NULL)
        {
            BigSums[l++] += strtol(token, NULL, 10);
            token = strtok(NULL, "-");
        }

        printf("ROUND : %d\n",num_of_rounds);
        for (l = 0; l < n; l++)
        {
            printf("BIGSUM %d : %d\n", l, BigSums[l]);
        }
        printf("\t------------\n");
        fflush(stdin);

        for (p = 0; p < n; p++)
        {
            if (BigSums[p] >= 50)
            {
                ended_flag = 1;
            }
        }

        if (ended_flag)
        {
            break;
        }
    }
    printf("\n\n\n\n\n\n");
    for (p = 0; p < n; p++)
    {
        if (BigSums[p] >= 50)
        {
            printf("Congratulations, Child %d Has Reached a Score of %d and thus He Has WON!!\n", p + 1, BigSums[p]);
        }
        else
        {
            printf("Unfortunately, Child %d Has NOT Reached a Score of 50, but instead %d, and thus He Has FAILED!!\n", p + 1, BigSums[p]);
        }
    }
    printf("\n\t\tThis Was Done in only %d  rounds :)\n", num_of_rounds);
    close(fd[0][0]);
    close(fd[1][0]);
    close(fd[1][1]);
    for (l = 1; l < n + 1; l++)
    {
        kill(pid[l], SIGKILL);
        waitpid(pid[l], NULL, 0);
        
    }
    kill(ref_pid, SIGKILL);
    waitpid(ref_pid, NULL, 0);
    return 0;
}
