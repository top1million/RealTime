#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
int exitt = 0;

int main(int argc,char* argv[]){
    if (argc != 2){
        printf("Please Enter the Total number Of Competants as an Argument!\n");
        return 1;
    }
    //n is the number of children
    int n = atoi(argv[1]);

    int fd[n+1][2]; //number of file descriptors
    int i;
    for (i = 0;i<=n;i++){
        if(pipe(fd[i])<0){
            return 2;
        }
    }

    int pid[n+1];
    for(i=1;i<n+1;i++){
        pid[i] = fork();
        if(pid[i] < 0){
            return i+2;
        }
        //ith child process
        if(pid[i] ==0){
            int c_pid = i; //current PID to save for later
            //closing the pipes
            for(int j=1;j<=n;j++){
                if (c_pid == j){
                    //we want to read
                    //from parent.
                    //and write to 
                    //current
                    close(fd[j][0]);
                    close(fd[0][1]);
                    continue;
                }
                close(fd[j][0]);
                close(fd[j][1]);

            }

            int v = 0;
            do{
                
                // printf("Test, %d, my pid is %d\n",c_pid,getpid());
                kill(getpid(),SIGSTOP);
                // printf("After Pause for process %d\n",c_pid);
                // usleep(c_pid * 1200); //to give random seeds for each process
                srand(clock()*c_pid);
                v = rand()%101;
                printf("Child %d has put %d \n",c_pid,v);
                if(write(fd[c_pid][1],&v,sizeof(int)) < 0){
                    return 11;
                }
            }
            while(exitt != 1);
            close(fd[c_pid][1]);
            close(fd[0][0]);
            return 0;

        }
        
    }
    //Main Parent Process
    int l = 1;
    int values[n+1];
    int max_pos;
    int scores[n+1];
    for(int g = 0; g < n+1;g++){
        scores[g]= 0;
    }
    while(1){
        usleep(5000);
        printf("----------------------------------------------------------------------------------\n");
        for(l = 1;l < n+1; l++){
            // printf("Before Killing Process %d with pid = %d\n",l,pid[l]);
            kill(pid[l],SIGCONT);
            // printf("Killed Process %d with pid = %d\n",l,pid[l]);
            if(read(fd[l][0],&values[l],sizeof(int))<0){
                return 13;
            }
            printf("Values of l for l = %d is = %d\n\n",l,values[l]);
        }
        int max = -1;
        max_pos = 0;
        for(l = 1;l < n+1; l++){
            if(values[l] > max){
                printf("Prev Max = %d, Current MAx Will Become %d and max_pos will become %d\n\n",max,values[l],l);
                max = values[l];
                max_pos = l;
            }
        }
        scores[max_pos]++;
        if(scores[max_pos] == 10){
            printf("Current Scores Are :\n");
            for(int i = 1; i < n+1 ; i++){
                printf("Score of %d is %d\n",i,scores[i]);
            }
            printf("\nChild %d is the Winner, Congratulations ! \n",max_pos);
            exitt = 1;
            break;
        }
    }
    
    for(int i = 0; i< n+1 ; i++){
        close(fd[i][0]);
        close(fd[i][1]);
    }
    for (l = 1; l< n+1;l++){
        kill(pid[l],SIGKILL);
        waitpid(pid[l],NULL,0);
    }
}